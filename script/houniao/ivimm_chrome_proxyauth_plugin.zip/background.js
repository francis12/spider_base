
            var config = {
                    mode: "fixed_servers",
                    rules: {
                      singleProxy: {
                        scheme: "http",
                        host: "http-dyn.abuyun.com",
                        port: parseInt(9020)
                      },
                      bypassList: ["foobar.com"]
                    }
                  };
         
            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
         
            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "HR3638A8UW55SVTD",
                        password: "44470BB2783B1DA7"
                    }
                };
            }
         
            chrome.webRequest.onAuthRequired.addListener(
                        callbackFn,
                        {urls: ["<all_urls>"]},
                        ['blocking']
            );
            